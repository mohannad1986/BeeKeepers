@extends('front.layout.master')
@section('title')
الصفحة التجريبية
@endsection

@section('page_title')

عنوان الصفحة الصغيرة
@endsection

@section('content')

{{-- ===================--}}


{{-- ================================================ --}}

@endsection




