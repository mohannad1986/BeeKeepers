<!DOCTYPE html>
<html lang="en" class="ie_11_scroll">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="hhhwidth=device-width, initial-scale=1">
    <title>welcom</title>
    <!-- CSS -->




    <link rel="stylesheet" href="{{asset('assets/dash/landcss/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/dash/landcss/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/dash/landcss/templatemo_style.css')}}">

</head>

<body>
    <!-- Top menu -->


    <!-- Home -->
    <section id="templatemo_home">
        <div class="container">
            <div class="templatemo_home_inner_wapper">
                <h1 class="text-center"> </h1>
            </div>
            <div class="templatemo_home_inner_wapper">
                <h2 class="text-center">BeeKeepers</h2>
                <p class="text-center" style="">
                    الموقع العربي الاكبر لتجمع النحالة وتجار العسل وتامين مستلزمات النحالة في العالم العربي
                </p>
            </div>
            <div class="templatemo_home_inner_wapper btn_wapper">
                <div class="col-sm-6">
                    <a href="{{route('rig')}}" class="btn col-xs-12 scroll_effect shadow-top-down">
                        <i class=""></i> انشاء حساب
                    </a>
                </div>
                <div class="col-sm-6">
                    <a href="{{route('log')}}" class="btn col-xs-12 scroll_effect shadow-top-down">
                        <i class=""></i> تسجيل دخول
                    </a>
                </div>
            </div>
        </div>
    </section>


</body>

</html>
