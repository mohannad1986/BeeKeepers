@extends('front.layout.mini_master')
@section('title')
انشاء حساب
@endsection



@section('content')

{{-- ===================--}}
المحتوى
{{-- ================================================ --}}

@endsection




