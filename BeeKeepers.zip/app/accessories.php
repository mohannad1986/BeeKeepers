<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class accessories extends Model
{
    protected $fillable = [
        'Product_name', 'description', 'p_photo'
        ];
}
