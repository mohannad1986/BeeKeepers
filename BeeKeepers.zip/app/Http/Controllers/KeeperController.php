<?php

namespace App\Http\Controllers;
use App\User;
use App\k_has_p;
use App\hproduct;
use App\hdealer_keeper;
use App\accdealer_keepers;
use Illuminate\Http\Request;

class KeeperController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)

    {
         return $id;
    }

    // public function index2($id)

    // {
    //     $keeper=user::find($id);
    //     // شيل السلكت اذا عملك اخطاء
    //     $orders=  User::select('id', 'name','email')->with('hdealer_keeper')->whereHas('hdealer_keeper', function ($q) use($id) {
    //         $q->where('keeper_id',$id);
    //     })->get();

    //     // $orders=  User::select('id', 'name','email')->wherehas(['hdealer_keeper'=> function ($q) use($id) {
    //     //     $q->where('offered_price','12');
    //     // }])->get();

    //     // الان بدي جيب شو عندو هالنحال منتجات
    //     $hasproducs=k_has_p::where('user_id',$id)-> with('hproduct')->get();

    //    $all_h_products= hproduct::select('id','Product_name')->get()  ;

    // //    return  $all_h_product;




    //     return view('keeper',compact('orders','hasproducs','all_h_products')) ;


    //     // return  $hasproduct;

    // }

    public function keeperproducts($id)

    {
        $hasproducs=k_has_p::where('user_id',$id)-> with('hproduct')->get();
        $all_h_products= hproduct::select('id','Product_name')->get();
        return view('front.keeper.keeperproducts',compact('hasproducs','all_h_products')) ;
    }

    public function honeyorders($id){




        $orders =hdealer_keeper::where('keeper_id',$id)->with(['honyDealer'=> function ($q){
          $q->select('id','name','email','prof_pic'); }])->get();

        return view('front.keeper.honeyorders',compact('orders')) ;

    }

    // هاد بيجيب للنحال شو قدم هوي طلبات شراء لمستلزمات
    // مع معلومات التاجر الي قدملو طلب الشراء
    public function keeper_acces_orders($id){

        $orders =accdealer_keepers::where('keeper_id',$id)->with(['accesdealers'=> function ($q){
          $q->select('id','name','email','prof_pic'); }])->get();


        return view('front.keeper.orderskeepermade',compact('orders')) ;

    }







}
