<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dash/css/styleph.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/dash/css/stylehidden.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>

الصفحة الاولى

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

الصفحة االاولى
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="hidden">


<div id ="accessories">

    <button class="close" onclick="document.getElementById('accessories').style.display='none'" >&#10006; Close</button>
		<header class="main-header clearfix">
			<h1 class="name" style="text-align: center;">اختيار مستلزمات</h1>
		</header>

		<div class="content clearfix">
            <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="cube-container">
				<div class="photo-cube">

					<img class="front img-responsive" src="<?php echo e(URL::asset('assets/dash/img/accessory')); ?>/<?php echo e($access->p_photo); ?>" alt="">
					<div class="back photo-desc">
					  <h3><?php echo e($access->Product_name); ?></h3>
					  <p><?php echo e($access->description); ?>.</p>
						<a href="<?php echo e(url('accesOwners')); ?>/<?php echo e($access->id); ?>" class="button">شراء</a>

					</div>
					<img class="left img-responsive" src="<?php echo e(URL::asset('assets/dash/img/accessory')); ?>/<?php echo e($access->p_photo); ?>" alt="">
					<img class="right img-responsive" src="<?php echo e(URL::asset('assets/dash/img/accessory')); ?>/<?php echo e($access->p_photo); ?>" alt="">

				</div>


			</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



		</div>
   </div>





   <div id ="honeyproduct">

    <button class="close" onclick="document.getElementById('honeyproduct').style.display='none'" >&#10006; Close</button>
		<header class="main-header clearfix">
			<h1 class="name"style="text-align: center;">اختيار منتج عسل</h1>
		</header>

		<div class="content clearfix">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			 <div class="cube-container">
				<div class="photo-cube">

					<img class="front"src="<?php echo e(URL::asset('assets/dash/img/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">
					<div class="back photo-desc">
					  <h3><?php echo e($product->Product_name); ?></h3>
					  <p><?php echo e($product->description); ?>.</p>
						<a href="<?php echo e(url('howner')); ?>/<?php echo e($product->id); ?>" class="button">شراء</a>
					</div>
					<img class="left" src="<?php echo e(URL::asset('assets/dash/img/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">
					<img class="right" src="<?php echo e(URL::asset('assets/dash/img/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">

				</div>
			</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
   </div>




</div>



<div class="oo" style="--n-rows: 3; --n-cols: 6">
    <style>
        .hex-cell:nth-of-type(5n + 1) {
            grid-column-start: 2
        }
    </style>
    
    <div class="hex-cell" ><img  class="img-responsive" onclick="honyFunction()"src="<?php echo e(URL::asset('assets/dash/img/honey.png')); ?>" /> </div>
    <div class="hex-cell"><img  class="img-responsive"  onclick="accesFunction()" src="<?php echo e(URL::asset('assets/dash/img/acees.png')); ?>" /></div>
    <div class="hex-cell"><img src="<?php echo e(URL::asset('assets/dash/img/Bee.png')); ?>" /></div>
    <div class="hex-cell"><img src="<?php echo e(URL::asset('assets/dash/img/Bee.png')); ?>" /></div>
    <div class="hex-cell"><img src="<?php echo e(URL::asset('assets/dash/img/Bee.png')); ?>" /></div>
    <div class="hex-cell"><img src="<?php echo e(URL::asset('assets/dash/img/Bee.png')); ?>" /></div>
    <div class="hex-cell"><img src="<?php echo e(URL::asset('assets/dash/img/Bee.png')); ?>" /></div>
</div>






<script>
window.onload = function() {
  document.getElementById('honeyproduct').style.display = 'none';
  document.getElementById('accessories').style.display = 'none';
};


function honyFunction() {
  var x = document.getElementById("honeyproduct");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
// سكربت المنتطلبات
function accesFunction() {
  var x = document.getElementById("accessories");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}


</script>



<?php $__env->stopSection(); ?>







<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/first.blade.php ENDPATH**/ ?>