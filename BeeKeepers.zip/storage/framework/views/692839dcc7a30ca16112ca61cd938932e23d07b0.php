<?php $__env->startSection('title'); ?>

المنحل

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/stylet.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




<!-- partial:index.partial.html -->
<div class="container">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<div class="table-users">
    <div class="header">طلبات الشراء</div>

    <table cellspacing="0">
       <tr>
          <th>Picture</th>
          <th >اسم التاجر</th>
          <th >الايميل</th>
          <th>الكمية المطلوبة</th>
          <th>سعر النحال </th>
          <th>السعر المعروض</th>
          
          <th>Comments</th>
       </tr>
       <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td><img src="https://i.picsum.photos/id/1025/100/100.jpg" alt="" /></td>
       <td><?php echo e($order->name); ?></td>
       <td><?php echo e($order->email); ?></td>
        <td><?php echo e($order->hdealer_keeper->amout); ?></td>
        <td><?php echo e($order->hdealer_keeper->keeper_price); ?></td>
        <td><?php echo e($order->hdealer_keeper->offered_price); ?></td>

       <td><a href="<?php echo e(url('accept_order')); ?>/<?php echo e($order->hdealer_keeper->id); ?>"> <button type="button" class="btn btn-info btn-sm">قبول </button> </a>
       <button type="button" class="btn  btn-sm btn-success" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($order->hdealer_keeper->id); ?>">رفض</button></td>
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </table>
</div>
</div>


    
<div class="container">

    <div class="gtco-section border-bottom"  style="margin-top: 0;  background: #e6e9eb;">
        <div class="gtco-container" style="margin-top: 0px ; padding-top: 0px; ">
            <div class="row">

                <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                    <h2>Beautiful Images</h2>
                    
                </div>
            </div>



            <div class="row">
                <?php $__currentLoopData = $hasproducs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-4 col-sm-6">
                        <a href="" data-toggle="modal" data-id="<?php echo e($product->id); ?>" data-amount="<?php echo e($product->amount); ?>" data-price="<?php echo e($product->price); ?>" data-target="#exampleModal3" class="fh5co-project-item image-popup" >
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                
                            </figure>
                            <?php  $hpro =  $product->hproduct; ?>

                            <div class="fh5co-text">
                                <h2><?php echo e($hpro->Product_name); ?></h2>
                                <p><?php echo e($product->price); ?> السعر <br> <?php echo e($product->amount); ?> الكمية</p>



                            </div>
                        </a>
                       
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4 col-md-4 col-sm-6">
                    <a href="images/img_4.jpg" data-toggle="modal" data-target="#exampleModal2" class="fh5co-project-item image-popup">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/img_4.jpg" alt="Image" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>اضافة منتج</h2>
                        </div>
                    </a>
                </div>

            </div>


        </div>
    </div>


 <!-- partial -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="exampleModalLabel" >هل انت متاكد من رفض الطلب ؟</h4>
      </div>
      <div class="modal-body">
        <form id='offerForm' method="post" action="<?php echo e(route('refuse_order')); ?>" style="direction: rtl;">
           <?php echo csrf_field(); ?>
            <input type="hidden" class="form-control" id="id" name ="id" value="">
      </div>
      <div class="modal-footer" style="floating: left;">
        <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
        <button  type="submit"   class="btn btn-primary">ارفض الطلب</button>
      </div>
    </form>
    </div>
  </div>
</div>



<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title text-center" id="exampleModalLabel" >اضافة منتج</h4>
        </div>
        <div class="modal-body">
          <form id='offerForm' method="post" action="<?php echo e(route('keeper_add_h')); ?>" style="direction: rtl;">
             <?php echo csrf_field(); ?>
              <input type="text" class="form-control" id="id" name ="userId" value="<?php echo e(auth()->user()->id); ?>">
              <div class="form-group">
                <label for="" class="control-label">اختيار المنتج </label>
                <select class="form-control" name ="select_product">
                <?php $__currentLoopData = $all_h_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->Product_name); ?></option>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="quantity">الكمية المتوفرة</label>
            <input type="number"  class="form-control" id="quantity" name="amount" min="0" max="">

            <label for="quantity">السعر</label>
            <input type="number"  class="form-control" id="" name="price" min="0" max="">

        </div>
        </div>
        <div class="moda2-footer" style="floating: left;">
          <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
          <button  type="submit"   class="btn btn-primary">اضافة المنتج </button>
        </div>
      </form>
      </div>
    </div>
  </div>




<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title text-center" id="exampleModalLabel" >تعديل منتج  </h4>
        </div>
        <div class="modal-body">
          <form id='offerForm' method="post" action="<?php echo e(route('keeper_update_h')); ?>" style="direction: rtl;">
             <?php echo csrf_field(); ?>
              <input type="text" class="form-control" id="id" name ="id" value="<?php echo e(auth()->user()->id); ?>">
              <div class="form-group">

            </select>
            <label for="quantity">تعديل الكمية</label>
            <input type="number"  class="form-control" id="amount" name="amount" value="">

            <label for="quantity">تعديل السعر</label>
            <input type="number"  class="form-control" id="price" name="price" value="">

        </div>
        </div>
        <div class="moda2-footer" style="floating: left;">
          <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
          <button  type="submit"   class="btn btn-primary">تعديل المنتج  </button>
        </div>
      </form>
      </div>
    </div>
  </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>





<script>
  $('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')
    var modal = $(this)
    modal.find('.modal-body  #id').val(id)
  })


//   ------------------------
// --سكربت المودل الثالث للخاص بتعديل المنتج --------------
$('#exampleModal3').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')
    var amount = button.data('amount')
    var price = button.data('price')

    var modal = $(this)
    modal.find('.modal-body  #id').val(id)
    modal.find('.modal-body  #amount').val(amount)
    modal.find('.modal-body  #price').val(price)


  })




  </script>
  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beekeepers\resources\views/keeper.blade.php ENDPATH**/ ?>