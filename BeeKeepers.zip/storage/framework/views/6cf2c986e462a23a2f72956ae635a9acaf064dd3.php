<?php $__env->startSection('title'); ?>
معدات لدى التاجر
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>


معدات لدى التاجر
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session()->has('message')): ?>
<div class="alert col-12  alert-info alert-shade alert-dismissible fade show" role="alert">
    <strong>مبروك! .</strong>  <strong class="fnt-code c-dark"><?php echo e(session()->get('message')); ?> .</strong>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

<?php if(session()->has('fail')): ?>'
   <div class="alert col-12  alert-forth alert-shade alert-dismissible fade show" role="alert">
    <strong>خطأ إدخال .!</strong> .. <strong class="fnt-code c-dark"><?php echo e(session()->get('fail')); ?></strong>
    .
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('   <div class="alert col-12  alert-forth alert-shade alert-dismissible fade show" role="alert">
    <strong>خطأ إدخال .!</strong> .. <strong class="fnt-code c-dark">:message</strong>
    .
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>')); ?>

<?php endif; ?>

<div class="row">
    <?php $__currentLoopData = $hasacces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasacce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6 col-md-4 col-lg-4">
      <div class="thumbnail text-center">
        <?php  $accessory = $hasacce->accessories; ?>
        <img src="<?php echo e(URL::asset('assets/dash/img/accessory')); ?>/<?php echo e($accessory->p_photo); ?>" alt="..."   height="200px" width="200px" class="img-responsive">
        <div class="caption">
          <h3 class="text-center"><?php echo e($accessory->Product_name); ?></h3>
          <p class="text-center"><?php echo e($hasacce->price); ?> السعر / <?php echo e($hasacce->amount); ?> الكمية</p>
          <div class="row">
            <?php if(Auth::user()->id == $hasacce->user_id ): ?>
                <div class="c-grey text-center col-6 ">
                    <button type="button" class="btn main f-success btn-block fnt-xxs"data-toggle="modal" data-id="<?php echo e($hasacce->id); ?>" data-amount="<?php echo e($hasacce->amount); ?>" data-price="<?php echo e($hasacce->price); ?>" data-target="#exampleModal3" onclick="toastr.error('في حال بقت الكمية صفرية لاكثر من اسبوع سيقوم النظام بحذق المنتج لديك', 'تحذير لكمية المنتج', {timeOut: 5000})" >نعديل</button>
                </div>
                <div class="c-grey text-center col-6 ">
                    <button type="button" class="btn main f-danger btn-block fnt-xxs"  data-toggle="modal"data-target="#exampleModal5" data-id="<?php echo e($hasacce->id); ?>">حذف</button>
                </div>
                <?php else: ?>
                <div class="c-grey text-center col-6 ">
                    <button type="button" class="btn main f-success btn-block fnt-xxs"data-toggle="modal"  data-accesdealerid="<?php echo e($hasacce->user_id); ?>"  data-amount="<?php echo e($hasacce->amount); ?>"   data-price="<?php echo e($hasacce->price); ?>"  data-accessoryid ="<?php echo e($hasacce->accessory_id); ?>"  data-target="#exampleModal9">شراء</button>
                </div>
                <?php endif; ?>

          </div>

        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<hr>
<div class="row">
    <div class="col-sm-6 col-md-4 col-lg-4">
        <div class="thumbnail text-center">
            <img src="<?php echo e(URL::asset('assets/dash/img/qq.jpg')); ?>" alt="..." height="200px" width="200px" class="img-responsive">
            <div class="caption">
                <h3 class="text-center"> اضافة منتج </h3>
                <p></p>
                <div class="c-grey text-center col-12 ">
                    <button type="button" class="btn main f-warning btn-block fnt-xxs"data-toggle="modal" data-target="#exampleModal2">اضافة منتج</button>
                </div>
            </div>
        </div>
    </div>

  </div>


</div>

 




	<!-- Modal -->
    <div class="modal w-lg fade light " id="exampleModal3" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
        <div class="modal-content card shade">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> تعدبل منتج </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               
               <form id='offerForm' method="post" action="<?php echo e(route('acdealer_has_acc')); ?>" style="direction: rtl;">
                <?php echo csrf_field(); ?>

                    <input type="hidden" class="form-control" id="id" name ="id" value="">

                    <div class="form-group">
                        <label for="" class="control-label">تعديل الكمية </label>
                        <input type="number" class="form-control" id="amount"    name="amount"  min="0" max=""  value="">
                    </div>
                    <div class="form-group">
                        <label for="quantity">تعديل السعر </label>
                        <input type="number"  class="form-control"  id="price" name="price"  min="0" max="" value="">
                    </div>





                    
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn outlined o-danger c-danger"
                            data-dismiss="modal">تراجع</button>
                    <button type="submit" class="btn outlined f-main">تعديل</button>
                    </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->




	<!-- Modal -->
    <div class="modal w-lg fade light " id="exampleModal2" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
        <div class="modal-content card shade">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> اضافة منتج</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <form id='offerForm' method="post" action="<?php echo e(route('dealer_add_acces')); ?>" style="direction: rtl;">
                <?php echo csrf_field(); ?>
                <input type="hidden" class="form-control" id="id" name ="userId" value="<?php echo e(auth()->user()->id); ?>">
                <div class="form-group">
                    <label for="" class="control-label">اختيار المنتج </label>
                    <select class="form-control" name ="select_accessorie">
                        <?php $__currentLoopData = $all_accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($accessorie->id); ?>"><?php echo e($accessorie->Product_name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                    <div class="form-group">
                        <label for="" class="control-label">الكمية المتوفرة</label>
                        <input type="number" class="form-control"  id="quantity" name="amount" min="0" max="">
                    </div>
                    <div class="form-group">
                        <label for="quantity"> السعر </label>
                        <input type="number"  class="form-control" id="" name="price" min="0" max="">
                    </div>

                    
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn outlined o-danger c-danger"
                            data-dismiss="modal">تراجع</button>
                    <button type="submit" class="btn outlined f-main">اضافة المنتج</button>
                    </div>
            </form>
        </div>
    </div>
</div>
</div>

<!-- Modal -->


<div class="modal w-lg fade light " id="exampleModal5" tabindex="-1" role="dialog"
aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog " role="document">
    <div class="modal-content card shade">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"> هل انت متاكد من حذف المنتج </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
           <form id='offerForm' method="post" action="<?php echo e(route('dealer_delete_acces')); ?>" style="direction: rtl;">
            <?php echo csrf_field(); ?>

             <input type="hidden" class="form-control" id="id" name ="id" value="">

                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn outlined o-danger c-danger"
                        data-dismiss="modal">تراجع</button>
                <button type="submit" class="btn outlined f-main">حذف المنتج </button>
                </div>
        </form>
    </div>
</div>
</div>






<div class="modal w-lg fade light " id="exampleModal9" tabindex="-1" role="dialog"
aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog " role="document">
    <div class="modal-content card shade">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"> طلب شراء</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
           
           <form id='offerForm' method="post" action="<?php echo e(route('order_acces')); ?>" style="direction: rtl;">
            <?php echo csrf_field(); ?>

             <input type="hidden" class="form-control" id="accesdealerid" name ="accesdealerid" value="">
             <input type="hidden" class="form-control" id="keeperid" name ="keeperid" value="<?php echo e(Auth()->user()->id); ?>">
             <input type="hidden" class="form-control" id="accessoryid"  name ="accessoryId" value="">



                <div class="form-group">
                    <label for="" class="control-label">الكمية المتوفرة</label>
                    <input type="text" class="form-control" id="amount"name ="amount" value="">
                </div>
                <div class="form-group">
                    <label for="quantity">الكمية المطلوبة</label>
                    <input type="number"  class="form-control" id="quantity" name="ordered_amount" min="0" max="">
                </div>

                <div class="form-group">
                    <label for="quantity">السعر للبيع</label>
                    <input type="text"  class="form-control" id="price" name="ordered_price" value="">
                </div>
                <div class="form-group">
                    <label for="quantity">عؤض سعر </label>
                    <input type="number"  class="form-control" id="offered_price" name="offered_price" min="0" max="">
                </div>



                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn outlined o-danger c-danger"
                        data-dismiss="modal">تراجع</button>
                <button type="submit" class="btn outlined f-main">شراء</button>
                </div>
        </form>
    </div>
</div>
</div>







<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>

    // --سكربت بتعديل المنتج ***
$('#exampleModal3').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')
    var amount = button.data('amount')
    var price = button.data('price')

    var modal = $(this)
    modal.find('.modal-body  #id').val(id)
    modal.find('.modal-body  #amount').val(amount)
    modal.find('.modal-body  #price').val(price)


  })
</script>
<script>
    // سكربت الحذف

  $('#exampleModal5').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')

    var modal = $(this)
    modal.find('.modal-body  #id').val(id)


  })
  </script>

  
  <script>


    $('#exampleModal9').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var recipient = button.data('whatever')
      var accesdealerid = button.data('accesdealerid')
      var amount = button.data('amount')
      var price = button.data('price')
      var accessoryid = button.data('accessoryid')

      var modal = $(this)

      modal.find('.modal-body  #accesdealerid').val(accesdealerid)
      modal.find('.modal-body  #amount').val(amount)
      modal.find('.modal-body  #price').val(price)
      modal.find('.modal-body  #accessoryid').val(accessoryid)

      // modal.find('.modal-body  #offered_price').val(price)

    })
    </script>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/acces_dealer/dealeraccessories.blade.php ENDPATH**/ ?>