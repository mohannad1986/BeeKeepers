<?php $__env->startSection('title'); ?>
طلبات الشراء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/stylet.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<div class="table-users">
    <div class="header">طلبات الشراء</div>

    <table cellspacing="0">
       <tr>
          <th>Picture</th>
          <th >اسم التاجر</th>
          <th >الايميل</th>
          <th >نوع العسل</th>

          <th>الكمية المطلوبة</th>
          <th>السعر المعروض</th>
          <th>الحالة </th>
          
          <th>Comments</th>
       </tr>
       <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td><img src="<?php echo e(URL::asset('assets/images/')); ?>/<?php echo e($order->honyDealer->prof_pic); ?>" alt="" /></td>
       <td><?php echo e($order->honyDealer->name); ?></td>
       <td><?php echo e($order->honyDealer->email); ?></td>
       <?php
           $proid=$order->productId;


           $ua=\App\hproduct::select('Product_name')->where('id',$proid)->first();
       ?>

       <td><?php echo e($ua->Product_name); ?> </td>
        <td><?php echo e($order->amout); ?></td>
        <td><?php echo e($order->offered_price); ?></td>
        <td><?php echo e($order->status); ?></td>


       <td><a href="<?php echo e(url('accept_order')); ?>/<?php echo e($order->id); ?>"> <button type="button" class="btn btn-info btn-sm">قبول </button> </a>
       <button type="button" class="btn  btn-sm btn-success" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($order->id); ?>">رفض</button></td>
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </table>
</div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title text-center" id="exampleModalLabel" >هل انت متاكد من رفض الطلب ؟</h4>
        </div>
        <div class="modal-body">
          <form id='offerForm' method="post" action="<?php echo e(route('refuse_order')); ?>" style="direction: rtl;">
             <?php echo csrf_field(); ?>
              <input type="hidden" class="form-control" id="id" name ="id" value="">
        </div>
        <div class="modal-footer" style="floating: left;">
          <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
          <button  type="submit"   class="btn btn-primary">ارفض الطلب</button>
        </div>
      </form>
      </div>
    </div>
  </div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>


    $('#exampleModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var id = button.data('id')
      var modal = $(this)
      modal.find('.modal-body  #id').val(id)
    })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/keeper/honeyorders.blade.php ENDPATH**/ ?>