<?php $__env->startSection('title'); ?>
الصفحة التجريبية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

عنوان الصفحة الصغيرة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>






<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/test.blade.php ENDPATH**/ ?>