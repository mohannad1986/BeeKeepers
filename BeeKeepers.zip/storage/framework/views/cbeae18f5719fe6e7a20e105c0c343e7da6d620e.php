<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div id= "honey">
    <div id="gtco-products" >
            <div class="gtco-container">
                <button class="close" onclick="document.getElementById('honey').style.display='none'" >&#10006; Close</button>
                <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                            <h2>More Products</h2>
                            <p>ias accusamus.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="owl-carousel owl-carousel-carousel">
                           <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item">
                              <h3 class="text-center"> <?php echo e($product->Product_name); ?></h3>
                            <a href="<?php echo e(url('howner')); ?>/<?php echo e($product->id); ?>"> <img src="<?php echo e(URL::asset('assets/images/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="Free HTML5 "></a>
                             <p><?php echo e($product->description); ?></p>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </div>
    </div>
</div>





<div id= "accessories">
    <div id="gtco-products" >
            <div class="gtco-container">
                <button class="close" onclick="document.getElementById('accessories').style.display='none'" >&#10006; Close</button>
                <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                            <h2>More Products</h2>
                            <p>ias accusamus.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="owl-carousel owl-carousel-carousel">
                           <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="item">
                              <h3 class="text-center"> <?php echo e($access->Product_name); ?></h3>
                            <a href="<?php echo e(url('accesOwners')); ?>/<?php echo e($access->id); ?>"> <img src="<?php echo e(URL::asset('assets/images')); ?>/<?php echo e($access->p_photo); ?>" alt="Free HTML5 "></a>
                             <p><?php echo e($access->description); ?></p>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </div>
    </div>
</div>




<div class="gtco-section border-bottom"  style="margin-top: 0;  background: #e6e9eb;">
    <div class="gtco-container" style="margin-top: 0px ; padding-top: 0px; ">
        <div class="row">

            <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                <h2>Beautiful Images</h2>

                <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-6">

                <a  onclick="honyFunction()"  class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_2.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">

                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>



            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a  onclick="accesFunction()" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_3.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_4.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_4.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_1.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_1.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_5.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_5.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_6.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_6.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>







<script>
    window.onload = function() {
  document.getElementById('honey').style.display = 'none';
  document.getElementById('accessories').style.display = 'none';
};

function honyFunction() {
  var x = document.getElementById("honey");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
// -- ------------------------نهاية السكربت الخاص بفتح اختيار منتجات عسل --------------------------------------- --}}

function accesFunction() {
  var x = document.getElementById("accessories");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}


</script>

<style>

</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views//first.blade.php ENDPATH**/ ?>