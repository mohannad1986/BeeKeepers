<?php $__env->startSection('title'); ?>

عسل النحال

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/stylet.css')); ?>">



<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="container">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <?php echo implode('', $errors->all('<div  class="alert alert-danger" role="alert">:message</div>')); ?>

<?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $hasproducs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <img src="..." alt="...">
            <div class="caption">
                <?php  $hpro =  $product->hproduct; ?>
              <h3><?php echo e($hpro->Product_name); ?></h3>
              <p><?php echo e($product->price); ?> السعر / <?php echo e($product->amount); ?> الكمية</p>
              <p><a href="#" class="btn btn-primary" role="button"  data-toggle="modal" data-id="<?php echo e($product->id); ?>" data-amount="<?php echo e($product->amount); ?>" data-price="<?php echo e($product->price); ?>" data-target="#exampleModal3" >تعديل</a> <a href="#" class="btn btn-default" role="button"  data-toggle="modal"data-target="#exampleModal5" data-id="<?php echo e($product->id); ?>">حذف</a></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
            <div class="thumbnail">
                <img src="..." alt="...">
                <div class="caption">
                    <h3> اضافة منتج </h3>
                    <p></p>
                    <p><a href="#" class="btn btn-primary" role="button" data-toggle="modal" data-target="#exampleModal2" >اضافة</a> <a href="#" class="btn btn-default" role="button">Button</a></p>
                </div>
            </div>
        </div>

      </div>
</div>



<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title text-center" id="exampleModalLabel" >تعديل منتج  </h4>
        </div>
        <div class="modal-body">
          <form id='offerForm' method="post" action="<?php echo e(route('keeper_update_h')); ?>" style="direction: rtl;">
             <?php echo csrf_field(); ?>
              <input type="text" class="form-control" id="id" name ="id" value="<?php echo e(auth()->user()->id); ?>">
              <div class="form-group">

            </select>
            <label for="quantity">تعديل الكمية</label>
            <input type="number"  class="form-control" id="amount" name="amount" value="">

            <label for="quantity">تعديل السعر</label>
            <input type="number"  class="form-control" id="price" name="price" value="">

        </div>
        </div>
        <div class="moda2-footer" style="floating: left;">
          <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
          <button  type="submit"   class="btn btn-primary">تعديل المنتج  </button>
        </div>
      </form>
      </div>
    </div>
  </div>





<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title text-center" id="exampleModalLabel" >اضافة منتج</h4>
        </div>
        <div class="modal-body">
          <form id='offerForm' method="post" action="<?php echo e(route('keeper_add_h')); ?>" style="direction: rtl;">
             <?php echo csrf_field(); ?>
              <input type="text" class="form-control" id="id" name ="userId" value="<?php echo e(auth()->user()->id); ?>">
              <div class="form-group">
                <label for="" class="control-label">اختيار المنتج </label>
                <select class="form-control" name ="select_product">
                <?php $__currentLoopData = $all_h_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->Product_name); ?></option>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="quantity">الكمية المتوفرة</label>
            <input type="number"  class="form-control" id="quantity" name="amount" min="0" max="">

            <label for="quantity">السعر</label>
            <input type="number"  class="form-control" id="" name="price" min="0" max="">

        </div>
        </div>
        <div class="moda2-footer" style="floating: left;">
          <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
          <button  type="submit"   class="btn btn-primary">اضافة المنتج </button>
        </div>
      </form>
      </div>
    </div>
  </div>



<div class="modal fade" id="exampleModal5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="exampleModalLabel" > هل انت متاكد من حذف المنتج</h4>
      </div>
      <div class="modal-body">
        <form id='offerForm' method="post" action="<?php echo e(route('keeperDeleteHoney')); ?>" style="direction: rtl;">
           <?php echo csrf_field(); ?>
            <input type="hidden" class="form-control" id="id" name ="id" value="">
            <div class="form-group">



      </div>
      </div>
      <div class="moda2-footer" style="floating: left;">
        <button type="button" class="btn btn-default" data-dismiss="modal">تراجع</button>
        <button  type="submit"   class="btn btn-primary"> حذف المنتج</button>
      </div>
    </form>
    </div>
  </div>
</div>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>

    // --سكربت المودل الثالث للخاص بتعديل المنتج --------------
$('#exampleModal3').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')
    var amount = button.data('amount')
    var price = button.data('price')

    var modal = $(this)
    modal.find('.modal-body  #id').val(id)
    modal.find('.modal-body  #amount').val(amount)
    modal.find('.modal-body  #price').val(price)


  })
</script>
<script>
  // سكربت الحذف

$('#exampleModal5').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var id = button.data('id')

  var modal = $(this)
  modal.find('.modal-body  #id').val(id)


})
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/keeper/keeperproducts.blade.php ENDPATH**/ ?>