<nav class="gtco-nav" role="navigation">
    <div class="gtco-container">

        <div class="row">
            <div class="col-sm-4 col-xs-12">
                <div id="gtco-logo"><a href="index.html">Splash <em>.</em></a></div>
            </div>
            <div class="col-xs-8 text-right menu-1">
                <ul>

                    <li class="has-dropdown">
                        <a href="#">Dropdown</a>
                        <ul class="dropdown">
                            <li><a href="#">Web Design</a></li>
                            <li><a href="#">eCommerce</a></li>
                            <li><a href="#">Branding</a></li>
                            <li><a href="#">API</a></li>
                        </ul>
                    </li>
                    
                    
                    

                    

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('دخول_تاجر')): ?>
                    <a href="<?php echo e(url('roles')); ?>" class="sidebar-toggle1"><i class="fa fa-2x fa-bars"></i>roles</a>


                    <li><a href="contact.html"><a href="<?php echo e(url('/logout')); ?>"> logout </a></a></li>
                    <li class="btn-cta"><a href="<?php echo e(url('keeper')); ?>/<?php echo e(Auth()->user()->id); ?>"><span><?php echo e(Auth()->user()->name); ?></span></a></li>
                    <li><img src="<?php echo e(URL::asset('assets/images')); ?>/<?php echo e(Auth()->user()->prof_pic); ?>"  class="img-circle" width="30px" height="30px" alt="..." ></li>

                    <li></li>

                    <li class="has-dropdown">
                        <a href="#">نحال</a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(url('keepers_hony')); ?>/<?php echo e(Auth()->user()->id); ?>">عسلي</a></li>
                            <li><a href="<?php echo e(url('keepers_h_order')); ?>/<?php echo e(Auth()->user()->id); ?>">طلبات شراء العسل مني</a></li>
                            <li><a href="#">Branding</a></li>
                            <li><a href="#">API</a></li>
                        </ul>
                    </li>

                    <li class="has-dropdown">
                        <a href="#">مستلزمات</a>
                        <ul class="dropdown">
                            <li><a href="<?php echo e(url('dealer_acces')); ?>/<?php echo e(Auth()->user()->id); ?>">مستلزماتي</a></li>

                            <li><a href="<?php echo e(url('accDealer_order')); ?>/<?php echo e(Auth()->user()->id); ?>">طلبات شرا المستلزمات مني</a></li>
                            <li><a href="#">API</a></li>
                        </ul>
                    </li>

                    
                    
                    


                    <?php endif; ?>
                </ul>
            </div>
        </div>

    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\beekeepers\resources\views/layouts/header.blade.php ENDPATH**/ ?>