<?php $__env->startSection('title'); ?>
المستخدمين المفعلين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
المستخدمين المفعلين
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
<div class="alert col-12  alert-info alert-shade alert-dismissible fade show" role="alert">
    <strong>مبروك! .</strong>  <strong class="fnt-code c-dark"><?php echo e(session()->get('message')); ?> .</strong>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>


<div class="col-xs-1 col-sm-1 col-md-8 col-lg-12 p-2">
    <div class="card shade h-100">
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;"></h5>

            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">الاسم</th>
                        <th scope="col">الايميل</th>
                        <th scope="col">الدور</th>
                        <th scope="col"></th>
                        <th scope="col"></th>


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(URL::asset('assets/dash/img/avatar')); ?>/<?php echo e($user->prof_pic); ?>" alt="..."
							class="rounded-circle screen-user-profile"></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                        <?php if(!empty($user->getRoleNames())): ?>
                            <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="badge badge-success"><?php echo e($v); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </td>
                        <td>
                            <div class="row">
                                <div class="c-grey text-center col-lg-6">

                                <button type="button"  data-toggle="modal"data-target="#exampleModal5" data-id="<?php echo e($user->id); ?>" class="btn main f-warning btn-block fnt-xxs ">حذف</button>

                                </div>
                                <div class="c-grey text-center col-lg-6 ">
                                    <a href="<?php echo e(route('dis_active',$user->id)); ?>">
                                <button type="button" class="btn main f-danger btn-block fnt-xxs "> الغاء تفعيل</button>
                                    </a>
                                </div>
                            </div>
                        </td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
                <div class="d-flex justify-content-center">
                <?php echo $data->render(); ?>

                </div>
        </div>

    </div>
</div>



<div class="modal w-lg fade light " id="exampleModal5" tabindex="-1" role="dialog"
aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog " role="document">
    <div class="modal-content card shade">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"> هل انت متاكد من حذف المستخدم </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
           <form id='offerForm' method="post" action="<?php echo e(route('destroy')); ?>" style="direction: rtl;">
            <?php echo csrf_field(); ?>

             <input type="text" class="form-control" id="id" name ="id" value="">

                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn outlined o-danger c-danger"
                        data-dismiss="modal">تراجع</button>
                <button type="submit" class="btn outlined f-main">حذف المستخدم </button>
                </div>
        </form>
    </div>
</div>
</div>








<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    // سكربت الحذف

  $('#exampleModal5').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var id = button.data('id')

    var modal = $(this)
    modal.find('.modal-body  #id').val(id)


  })
  </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/dashboard/users/active1.blade.php ENDPATH**/ ?>