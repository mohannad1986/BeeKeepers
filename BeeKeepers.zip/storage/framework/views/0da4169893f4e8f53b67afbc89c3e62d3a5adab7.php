<?php $__env->startSection('title'); ?>
انشاء حساب
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


المحتوى


<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.mini_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/mini_test.blade.php ENDPATH**/ ?>