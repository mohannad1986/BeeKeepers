<!doctype html>
<html class="no-js" lang="">

<head>
	<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>

<body class="rtl">

	<div class="bmd-layout-container bmd-drawer-f-l avam-container animated bmd-drawer-in">
        <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div id="dw-s1" class="bmd-layout-drawer bg-faded">

			<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		</div>
		<!-- -------------بداية المحتوى--------------------- -->
		<main class="bmd-layout-content">
			<div class="container-fluid ">
              

                <div class="row">
                    <div class="page-header breadcrumb-header p-3 mr-2 ml-2 m-2">
                        <div class="row align-items-end ">
                            <div class="col-lg-8">
                                <div class="page-header-title text-left-rtl">
                                    <div class="d-inline">
                                        <h3 class="lite-text "><?php echo $__env->yieldContent('page_title'); ?></h3>
                                        <span class="lite-text text-gray"> Options of Input</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item "><a href="#"><i class="fas fa-home"></i></a></li>
                                    <li class="breadcrumb-item "><a href="#">Component</a></li>
                                    <li class="breadcrumb-item active">Input</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="jumbotron shade pt-5">  <!-- هون بداية المحتوى الحقيقي-->

			    <?php echo $__env->yieldContent('content'); ?>
                </div>   <!-- هون نهاية المحتوى الحقيقي-->

            </div>
		</main>
		<!-- ---------------نهاية المحتوى------------------------ -->
	</div> <!-- هاد الدف تبع الكلاس الي بعد البودي  -->


	</div> <!-- هاد دف البدي  -->




 <?php echo $__env->make('admin.layout.footer_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>