<?php $__env->startSection('title'); ?>
نحالة لديهم منتجات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

نحالة لديهم منتجات عسل
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="col-xs-1 col-sm-1 col-md-8 col-lg-12 p-2">
    <div class="card shade h-100">
        <div class="card-body">
            <h5 class="card-title">Table Item</h5>

            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">الاسم</th>
                        <th scope="col">الايميل</th>
                        <th scope="col">الكمية</th>
                        <th scope="col">السعر</th>
                        <th scope="col">طلب</th>


                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td><div class="c-grey text-center col ">
							<button type="button" data-target="#exampleModal5" data-toggle="modal"
								class="btn flat f-second btn-block fnt-xxs ">شراء</button>
						</div></td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</div>



	<!-- Modal -->
    <div class="modal w-lg fade light " id="exampleModal5" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
        <div class="modal-content card shade">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Woohoo, you're reading this text in a modal!
            </div>
            <div class="modal-footer">
                <button type="button" class="btn outlined o-danger c-danger"
                    data-dismiss="modal">Close</button>
                <button type="button" class="btn outlined f-main">Save changes</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->



<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/khasp.blade.php ENDPATH**/ ?>