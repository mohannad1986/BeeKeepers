<div class="gtco-container">
    <div class="row row-p	b-md">

        <div class="col-md-4">
            <div class="gtco-widget">
                <h3>About <span class="footer-logo">Splash<span>.<span></span></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore eos molestias quod sint ipsum possimus temporibus officia iste perspiciatis consectetur in fugiat repudiandae cum. Totam cupiditate nostrum ut neque ab?</p>
            </div>
        </div>

        <div class="col-md-4 col-md-push-1">
            <div class="gtco-widget">
                <h3>Links</h3>
                <ul class="gtco-footer-links">
                    <li><a href="#">Knowledge Base</a></li>
                    <li><a href="#">Career</a></li>
                    <li><a href="#">Press</a></li>
                    <li><a href="#">Terms of services</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-4">
            <div class="gtco-widget">
                <h3>Get In Touch</h3>
                <ul class="gtco-quick-contact">
                    <li><a href="#"><i class="icon-phone"></i> +1 234 567 890</a></li>
                    <li><a href="#"><i class="icon-mail2"></i> info@FreeHTML5.co</a></li>
                    <li><a href="#"><i class="icon-chat"></i> Live Chat</a></li>
                </ul>
            </div>
        </div>

    </div>

    <div class="row copyright">
        <div class="col-md-12">
            <p class="pull-left">
                <small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small>
                <small class="block">Designed by <a href="http://FreeHTML5.co/" target="_blank">FreeHTML5.co</a> Demo Images: <a href="http://unsplash.co/" target="_blank">Unsplash</a></small>
            </p>
            <p class="pull-right">
                <ul class="gtco-social-icons pull-right">
                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                    <li><a href="#"><i class="icon-linkedin"></i></a></li>
                    <li><a href="#"><i class="icon-dribbble"></i></a></li>
                </ul>
            </p>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\beekeepers\resources\views/layouts/footer.blade.php ENDPATH**/ ?>