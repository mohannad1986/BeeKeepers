<!doctype html>
<html class="no-js" lang="">

<head>
	<?php echo $__env->make('front.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>

<body class="rtl" style="background-image: url({assets('assets/dash/img/back.png')})"  >

    <div class="bmd-layout-container bmd-drawer-f-l avam-container animated ">
        <main class="bmd-layout-content">
            <div class="container-fluid">
                <div class="main_wrapper">

		<!-- -------------بداية المحتوى--------------------- -->
          <?php echo $__env->yieldContent('content'); ?>
		<!-- ---------------نهاية المحتوى------------------------ -->
                </div>

            </div>
        </main>
    </div>
</div>





<?php echo $__env->make('front.layout.footer_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/layout/mini_master.blade.php ENDPATH**/ ?>