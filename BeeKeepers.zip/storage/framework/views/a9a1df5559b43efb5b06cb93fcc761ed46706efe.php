<?php $__env->startSection('title'); ?>
لوحة القيادة والتحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
لوحة القيادة والتحكم

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>






<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/dashboard/test.blade.php ENDPATH**/ ?>