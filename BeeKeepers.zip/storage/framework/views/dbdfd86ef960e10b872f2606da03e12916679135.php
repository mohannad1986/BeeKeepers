<?php $__env->startSection('title'); ?>

تجار المستلزمات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/stylet.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




<!-- partial:index.partial.html -->
<div class="container">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <?php echo implode('', $errors->all('<div  class="alert alert-danger" role="alert">:message</div>')); ?>

<?php endif; ?>

<?php if($lolos->isEmpty()): ?>
<div  class="alert alert-danger text-center" role="alert"> المنتج غير متوافر حاليا  </div>'

<?php endif; ?>
<div class="table-users">

    <div class="header"><?php echo e($accesName); ?></div>

    <table cellspacing="0">
       <tr>
          <th>Picture</th>
          <th >الاسم</th>
          <th >الايميل</th>
          <th>الكمية</th>
          <th>السعر</th>
          
          <th width="230">Comments</th>

       </tr>




       


       <?php $__currentLoopData = $lolos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lolo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td><img src="<?php echo e(URL::asset('assets/images/')); ?>/<?php echo e($lolo->allAccesDealers->prof_pic); ?>" alt="" /></td>
       <td><?php echo e($lolo->allAccesDealers->name); ?></td>
       <td><?php echo e($lolo->allAccesDealers->email); ?></td>


          <td><?php echo e($lolo->amount); ?></td>
          <td><?php echo e($lolo->price); ?></td>


       
       <td> <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal" data-accesdealerid="<?php echo e($lolo->allAccesDealers->id); ?>"  data-amount="<?php echo e($lolo->amount); ?>"  data-price="<?php echo e($lolo->price); ?>" >شراء</button></td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







    </table>



 </div>


</div>
 <!-- partial -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="exampleModalLabel" >قسيمة طلب مستلزمات</h4>
      </div>
      <div class="modal-body">
        <form id='offerForm' method="post" action="<?php echo e(route('order_acces')); ?>" style="direction: rtl;">
           <?php echo csrf_field(); ?>

            <input type="text" class="form-control" id="accesdealerid" name ="accesdealerid" value="">
            <input type="hidden" class="form-control" id="keeperid" name ="keeperid" value="<?php echo e(Auth()->user()->id); ?>">
            <input type="text" class="form-control"  name ="accessoryId" value="<?php echo e($acces_id); ?>">



          <div class="form-group">
            <label for="" class="control-label">الكمية المتوفرة</label>
            <input type="text" class="form-control" id="amount"name ="amount" value="">
          </div>
          <div class="form-group">
            <label for="quantity">الكمية المطلوبة</label>
              <input type="number"  class="form-control" id="quantity" name="ordered_amount" min="0" max="">
          </div>

          <div class="form-group">
            <label for="quantity">السعر للبيع</label>
              <input type="text"  class="form-control" id="price" name="ordered_price" value="">
          </div>
          <div class="form-group">
            <label for="quantity">عؤض سعر </label>
              <input type="number"  class="form-control" id="offered_price" name="offered_price" min="0" max="">
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button  type="submit"   class="btn btn-primary">Send message</button>
      </div>
    </form>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>





<script>
  $('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var recipient = button.data('whatever')
    var accesdealerid = button.data('accesdealerid')
    var amount = button.data('amount')
    var price = button.data('price') // Extract info from data-* attributes
    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
    var modal = $(this)
    // modal.find('.modal-title').text('New message to ' + recipient)
    // modal.find('.modal-body #recipient-name').val(recipient)
    modal.find('.modal-body  #accesdealerid').val(accesdealerid)
    modal.find('.modal-body  #amount').val(amount)
    modal.find('.modal-body  #price').val(price)
    // modal.find('.modal-body  #offered_price').val(price)

  })
  </script>
  
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/accessorydealers.blade.php ENDPATH**/ ?>