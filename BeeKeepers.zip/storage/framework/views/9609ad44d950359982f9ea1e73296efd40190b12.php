<?php $__env->startSection('title'); ?>
انشاء حساب
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<!-- form -->

<div class="row ">
    <div class="col-md-5 card shade mw-center mh-center">
        <img src="<?php echo e(asset('assets/dash/svg/logo.svg')); ?>" alt="..." class="mw-center " height="130" width="300" >
        <hr class="hr-dashed m-0">
        <form class="">
            <div class="form-group m-0">
                <label for="exampleInputEmail1">اسم المستخدم</label>
                <input type="text" class="form-control" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="ادخل اسمك">
                <small id="emailHelp" class="form-text text-muted">.</small>
            </div>
            <div class="form-group m-0">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1"
                    placeholder="Password">
            </div>
            <div class="form-check pt-2">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn shade f-primary btn-block">تسجيل الدخول</button>
        </form>
    </div>

</div>
<!--  -->




<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.mini_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/login.blade.php ENDPATH**/ ?>