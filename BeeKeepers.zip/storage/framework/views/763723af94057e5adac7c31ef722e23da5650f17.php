

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>
<!-- jQuery Easing -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
<!-- Bootstrap -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Waypoints -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.waypoints.min.js')); ?>"></script>
<!-- Carousel -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/owl.carousel.min.js')); ?>"></script>
<!-- countTo -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.countTo.js')); ?>"></script>
<!-- Magnific Popup -->


<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>

<!-- Main -->

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>



<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH C:\xampp\htdocs\test_dash\resources\views/layouts/script-footer.blade.php ENDPATH**/ ?>