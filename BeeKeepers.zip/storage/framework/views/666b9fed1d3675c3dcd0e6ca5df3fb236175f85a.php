<?php $__env->startSection('title'); ?>
انشاء حساب
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<div class="row ">
    <div class="col-md-8 card shade mw-center mh-center">
        <img src="<?php echo e(asset('assets/dash/svg/logo.svg')); ?>" alt="..." class="mw-center " height="130" width="300">
        <hr class="hr-dashed m-0">
        <form class="">
            <div class="form-group m-0">
                <label for="exampleInputEmail1">اسم المستخدم</label>
                <input type="text" class="form-control" id="" aria-describedby="" placeholder="ادخل اسمك">
            </div>
            <div class="form-group m-0">
                <label for="exampleInputEmail1">البريد الالكتروني</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ادخل بريدك الالكتروني" autocomplete="off">
                <small id="emailHelp" class="form-text text-muted"></small>
            </div>
            <div class="form-group m-0">
                <label for="exampleInputPassword1">كلمة السر</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>
            <div class="form-group m-0">
                <label for="exampleInputPassword1">تاكيد كلمة السر</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>
            <div class="form-group m-0">
                <label for="">نوع المستخدم</label>
                <select name="1A" id="select" class="form-control" autocomplete="off" required>
                    <option>نحال</option>
                    <option>تاجر مستلزمات</option>
                    <option>تاجر عسل</option>
                </select>
            </div>
            <div class="form-group m-0">
                <label for="exampleInputPassword1">صورتك </label>
                <input type="file" id="avatar" class="form-control" name="avatar" accept="image/png, image/jpeg">

            </div>


            <div class="form-check pt-2">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn shade f-primary btn-block">انشاء حساب</button>
        </form>
    </div>

</div>



<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.mini_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/rigester.blade.php ENDPATH**/ ?>