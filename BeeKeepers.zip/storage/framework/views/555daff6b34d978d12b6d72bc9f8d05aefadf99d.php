<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dash/css/styleph.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/dash/css/stylehidden.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>

الصفحة الاولى

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

الصفحة االاولى
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="hidden">


<div id ="accessories">

    <button class="close" onclick="document.getElementById('accessories').style.display='none'" >&#10006; Close</button>
		<header class="main-header clearfix">
			<h1 class="name" style="text-align: center;">اختيار مستلزمات</h1>
		</header>

		<div class="content clearfix">
            <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="cube-container">
				<div class="photo-cube">

					<img class="front" src="<?php echo e(URL::asset('assets/images')); ?>/<?php echo e($access->p_photo); ?>" alt="">
					<div class="back photo-desc">
					  <h3><?php echo e($access->Product_name); ?></h3>
					  <p><?php echo e($access->description); ?>.</p>
						<a href="<?php echo e(url('accesOwners')); ?>/<?php echo e($access->id); ?>" class="button">شراء</a>

					</div>
					<img class="left" src="<?php echo e(URL::asset('assets/images')); ?>/<?php echo e($access->p_photo); ?>" alt="">
					<img class="right" src="<?php echo e(URL::asset('assets/images')); ?>/<?php echo e($access->p_photo); ?>" alt="">

				</div>


			</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



		</div>
   </div>





   <div id ="honeyproduct">

    <button class="close" onclick="document.getElementById('honeyproduct').style.display='none'" >&#10006; Close</button>
		<header class="main-header clearfix">
			<h1 class="name"style="text-align: center;">اختيار منتج عسل</h1>
		</header>

		<div class="content clearfix">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			 <div class="cube-container">
				<div class="photo-cube">

					<img class="front"src="<?php echo e(URL::asset('assets/images/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">
					<div class="back photo-desc">
					  <h3><?php echo e($product->Product_name); ?></h3>
					  <p><?php echo e($product->description); ?>.</p>
						<a href="<?php echo e(url('howner')); ?>/<?php echo e($product->id); ?>" class="button">شراء</a>
					</div>
					<img class="left" src="<?php echo e(URL::asset('assets/images/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">
					<img class="right" src="<?php echo e(URL::asset('assets/images/hproducts')); ?>/<?php echo e($product->p_photo); ?>" alt="">

				</div>
			</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
   </div>




</div>



<div class="oo" style="--n-rows: 3; --n-cols: 6">
    <style>
        .hex-cell:nth-of-type(5n + 1) {
            grid-column-start: 2
        }
    </style>
    <div class="hex-cell" ><img  onclick="honyFunction()"src="https://images.unsplash.com/photo-1519681393784-d120267933ba?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img  onclick="accesFunction()" src="https://images.unsplash.com/photo-1497733942558-e74c87ef89db?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img src="https://images.unsplash.com/photo-1540744276164-9dc898353c7b?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img src="https://images.unsplash.com/photo-1469975692758-66d107a536cb?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img src="https://images.unsplash.com/photo-1490845060161-85f9ce08a9f4?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img src="https://images.unsplash.com/photo-1541673504494-8bcc1a340180?w=650&amp;fm=jpg" /></div>
    <div class="hex-cell"><img src="https://images.unsplash.com/photo-1515937350506-3e7b51a95339?w=650&amp;fm=jpg" /></div>
</div>






<script>
window.onload = function() {
  document.getElementById('honeyproduct').style.display = 'none';
  document.getElementById('accessories').style.display = 'none';
};


function honyFunction() {
  var x = document.getElementById("honeyproduct");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
// سكربت المنتطلبات
function accesFunction() {
  var x = document.getElementById("accessories");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}


</script>



<?php $__env->stopSection(); ?>







<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/admin/first.blade.php ENDPATH**/ ?>