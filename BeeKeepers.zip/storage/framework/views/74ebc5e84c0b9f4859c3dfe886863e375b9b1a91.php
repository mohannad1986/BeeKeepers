<?php $__env->startSection('title'); ?>
طلبات شراء مستلزمات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

طلبات شراء مستلزمات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(session()->has('message')): ?>
<div class="alert col-12  alert-info alert-shade alert-dismissible fade show" role="alert">
    <strong>مبروك! .</strong>  <strong class="fnt-code c-dark"><?php echo e(session()->get('message')); ?> .</strong>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>



<div class="col-xs-1 col-sm-1 col-md-12 col-lg-12 p-2">
    <div class="card shade h-100">
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;"></h5>

            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">اسم النحال</th>
                        <th scope="col">الايميل</th>
                        <th scope="col">نوع  المستلزم </th>
                        <th scope="col">الكمية المطلوبة</th>
                        <th scope="col">السعر المعروض</th>
                        <th scope="col">الحالة</th>
                        <th scope="col">التصرف</th>



                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(URL::asset('assets/dash/img/avatar')); ?>/<?php echo e($order->keepersOrderAcces->prof_pic); ?>" alt="..."
							class="rounded-circle screen-user-profile"></td>
                            <td><?php echo e($order->keepersOrderAcces->name); ?></td>
                            <td><?php echo e($order->keepersOrderAcces->email); ?></td>
                            <?php
                            $proid=$order->accessoryId;


                            $ua=\App\accessories::select('Product_name')->where('id',$proid)->first();
                        ?>
                       <td><?php echo e($ua->Product_name); ?> </td>
                       <td><?php echo e($order->amout); ?></td>
                       <td><?php echo e($order->offered_price); ?></td>
                       <td><?php echo e($order->status); ?></td>
                        <td>
                        <div class="row">
                        <div class="c-grey text-center col-6 ">
                            <a href="<?php echo e(url('accept_ACCorder')); ?>/<?php echo e($order->id); ?>"><button type="button"  class="btn main f-warning btn-block fnt-xxl ">قبول</button></a>
                        </div>
                        <div class="c-grey text-center col-6 ">

			                <button type="button" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($order->id); ?>" class="btn main f-success btn-block fnt-xxs ">رفض</button>
                        </div>
                        </div>
						</td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>
</div>


<!-- Modal -->
<div class="modal w-lg fade light " id="exampleModal" tabindex="-1" role="dialog"
aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog " role="document">
    <div class="modal-content card shade">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">هل انت متاكد من رفض الطلب ؟</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
           
           <form id='offerForm' method="post" action="<?php echo e(route('refuse_ACCorder')); ?>" style="direction: rtl;">
            <?php echo csrf_field(); ?>
            <input type="hidden" class="form-control" id="id" name ="id" value="">

                
             </div>
                <div class="modal-footer">
                    <button type="button" class="btn outlined o-danger c-danger"
                        data-dismiss="modal">تراجع</button>
                <button type="submit" class="btn outlined f-main">ارفض الطلب</button>
                </div>
        </form>
    </div>
</div>
</div>

<!-- Modal -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>


    $('#exampleModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var id = button.data('id')
      var modal = $(this)
      modal.find('.modal-body  #id').val(id)
    })

</script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/acces_dealer/acces_orders.blade.php ENDPATH**/ ?>