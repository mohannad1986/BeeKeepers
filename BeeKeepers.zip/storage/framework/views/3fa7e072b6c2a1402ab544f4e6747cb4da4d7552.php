<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div id= "my"  style="">
    <div id="gtco-products">

            <div class="gtco-container">

                <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                            <h2>More Products</h2>
                            <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="owl-carousel owl-carousel-carousel">
                            <div class="item">
                                <a href="#"><img src="images/img_1.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/img_2.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/img_3.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"></a>
                            </div>
                            <div class="item">
                                <a href="#"><img src="images/img_4.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"></a>
                            </div>
                        </div>
                    </div>

            </div>

    </div>
</div>




<div class="gtco-section border-bottom"  style="margin-top: 0;  background: #e6e9eb;">
    <div class="gtco-container" style="margin-top: 0px ; padding-top: 0px; ">
        <div class="row">

            <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                <h2>Beautiful Images</h2>
                <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-6">

                <a  onclick="myFunction()"  class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_2.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">

                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>



            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_3.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_3.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_4.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_4.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_1.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_1.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_5.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_5.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <a href="images/img_6.jpg" class="fh5co-project-item image-popup">
                    <figure>
                        <div class="overlay"><i class="ti-plus"></i></div>
                        <img src="images/img_6.jpg" alt="Image" class="img-responsive">
                    </figure>
                    <div class="fh5co-text">
                        <h2>Constructive heading</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>







<script>
    window.onload = function() {
  document.getElementById('my').style.display = 'none';
};

function myFunction() {
  var x = document.getElementById("my");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}


</script>
<style>

</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beekeepers\resources\views/first.blade.php ENDPATH**/ ?>