<?php $__env->startSection('title'); ?>
تجار مستلزمات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

تجار مستلزمات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
<div class="alert col-12  alert-info alert-shade alert-dismissible fade show" role="alert">
    <strong>مبروك! .</strong>  <strong class="fnt-code c-dark"><?php echo e(session()->get('message')); ?> .</strong>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('   <div class="alert col-12  alert-forth alert-shade alert-dismissible fade show" role="alert">
    <strong>خطأ إدخال .!</strong> .. <strong class="fnt-code c-dark">:message</strong>
    .
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>')); ?>

<?php endif; ?>







<div class="col-xs-1 col-sm-1 col-md-12 col-lg-12 p-2">
    <div class="card shade h-100">
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;"><?php echo e($accesName); ?></h5>

            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">الاسم</th>
                        <th scope="col">الايميل</th>
                        <th scope="col">الكمية</th>
                        <th scope="col">السعر</th>
                        <th scope="col">طلب</th>


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $lolos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lolo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(URL::asset('assets/dash/img/avatar')); ?>/<?php echo e($lolo->allAccesDealers->prof_pic); ?>" alt="..."
							class="rounded-circle screen-user-profile"></td>
                        <td><a href="<?php echo e(url('visitAccesDealer')); ?>/<?php echo e($lolo->allAccesDealers->id); ?>" ><?php echo e($lolo->allAccesDealers->name); ?></a></td>
                        <td><?php echo e($lolo->allAccesDealers->email); ?></td>
                        <td><?php echo e($lolo->amount); ?></td>
                        <td><?php echo e($lolo->price); ?></td>
                        <td><div class="c-grey text-center col ">
							<button type="button" data-target="#exampleModal5" data-toggle="modal"  data-accesdealerid="<?php echo e($lolo->allAccesDealers->id); ?>"  data-amount="<?php echo e($lolo->amount); ?>"  data-price="<?php echo e($lolo->price); ?>"  class="btn flat f-second btn-block fnt-xxs ">شراء</button>
						</div></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>
</div>


	<!-- Modal -->
    <div class="modal w-lg fade light " id="exampleModal5" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
        <div class="modal-content card shade">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               
               <form id='offerForm' method="post" action="<?php echo e(route('order_acces')); ?>" style="direction: rtl;">
                <?php echo csrf_field(); ?>

                 <input type="hidden" class="form-control" id="accesdealerid" name ="accesdealerid" value="">
                 <input type="hidden" class="form-control" id="keeperid" name ="keeperid" value="<?php echo e(Auth()->user()->id); ?>">
                 <input type="hidden" class="form-control"  name ="accessoryId" value="<?php echo e($acces_id); ?>">



                    <div class="form-group">
                        <label for="" class="control-label">الكمية المتوفرة</label>
                        <input type="text" class="form-control" id="amount"name ="amount" value="">
                    </div>
                    <div class="form-group">
                        <label for="quantity">الكمية المطلوبة</label>
                        <input type="number"  class="form-control" id="quantity" name="ordered_amount" min="0" max="">
                    </div>

                    <div class="form-group">
                        <label for="quantity">السعر للبيع</label>
                        <input type="text"  class="form-control" id="price" name="ordered_price" value="">
                    </div>
                    <div class="form-group">
                        <label for="quantity">عؤض سعر </label>
                        <input type="number"  class="form-control" id="offered_price" name="offered_price" min="0" max="">
                    </div>



                    
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn outlined o-danger c-danger"
                            data-dismiss="modal">تراجع</button>
                    <button type="submit" class="btn outlined f-main">شراء</button>
                    </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
<script>


    $('#exampleModal5').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var recipient = button.data('whatever')
      var accesdealerid = button.data('accesdealerid')
      var amount = button.data('amount')
      var price = button.data('price') // Extract info from data-* attributes
      // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
      // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
      var modal = $(this)
      // modal.find('.modal-title').text('New message to ' + recipient)
      // modal.find('.modal-body #recipient-name').val(recipient)
      modal.find('.modal-body  #accesdealerid').val(accesdealerid)
      modal.find('.modal-body  #amount').val(amount)
      modal.find('.modal-body  #price').val(price)
      // modal.find('.modal-body  #offered_price').val(price)

    })
    </script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/accessorydealers.blade.php ENDPATH**/ ?>