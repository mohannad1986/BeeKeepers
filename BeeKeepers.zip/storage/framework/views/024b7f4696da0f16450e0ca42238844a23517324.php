<?php $__env->startSection('title'); ?>
طلبات شراء قدمها النحال
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>

  طلبات شراء قدمها النحال
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<div class="col-xs-1 col-sm-1 col-md-12 col-lg-12 p-2">
    <div class="card shade h-100">
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;"></h5>

            <hr>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">الاسم</th>
                        <th scope="col">الايميل</th>
                        <th scope="col">نوع  العسل </th>
                        <th scope="col">الكمية المطلوبة</th>
                        <th scope="col">السعر المعروض</th>
                        <th scope="col">الحالة</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(URL::asset('assets/dash/img/avatar')); ?>/<?php echo e($order->accesdealers->prof_pic); ?>" alt="..."
							class="rounded-circle screen-user-profile"  width="40px" height="40px"></td>
                        <td><?php echo e($order->accesdealers->name); ?></td>
                        <td><?php echo e($order->accesdealers->email); ?></td>
                        <?php
                        $proid=$order->accessoryId;


                        $ua=\App\accessories::select('Product_name')->where('id',$proid)->first();
                    ?>
                        <td><?php echo e($ua->Product_name); ?></td>
                        <td><?php echo e($order->amout); ?></td>
                        <td><?php echo e($order->offered_price); ?></td>
                        <td><?php echo e($order->status); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>
</div>




<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_dash\resources\views/front/keeper/orderskeepermade.blade.php ENDPATH**/ ?>