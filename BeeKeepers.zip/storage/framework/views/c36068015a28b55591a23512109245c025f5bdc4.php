<?php $__env->startSection('title'); ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(".sidebar-toggle1").click(function(){
        $("#sidebar").toggleClass("sidebar-collapse");
        $("#main").toggleClass("main-expand");
    })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beekeepers\resources\views/test2.blade.php ENDPATH**/ ?>